#1)arthematic operator
#the arthematic operators used to perform mathematical operations b/w two variables
#they are difference types (+,-,*,/,//,%,**)
#example
#1)addition
a=5
b=10
c=a+b
print(c)
#15
#2)subtraction
a=10
b=5
c=a-b
print(c)
#multiplication
a=5
b=5
c=a*5
print(c)
#division
a=10
b=5
c=a/b
print(c)
#floor division
a=10
b=5
c=a//b
print(c)
#modules(reminder)
a=10
b=5
c=10%5
print(c)
#exponentiation
a=2
b=3
c=a**3
print(c)

#2)comparision operator
#the comparision operator used to compare values of two variables(==,!=,>,<,>=,<=)
#*)equal to
a=5
b=5
print(a==b)
#*)not equalto(!=)
a=5
b=5
print(a!=b)
#*)greate than (>)
a=10
b=5
print(a>b)
#*)lessthan(<)
a=5
b=10
print(a<b)
#*)greaterthan equal
a=10
b=10
print(a>=b)
#*)lessthan equal
a=9
b=10
print(a<=b)
#Identity Operations
#Used to compare object memory locations.
# the identity operator used to compare the adreess of a variable in the memory
# they are two types one is is and is not

a=5
b=5
print(a is b) #print true  it checks the address here both variables have same adress so it is printing true
#is not if the variable adress is same but we are telling that same are not same so in this case it will print fals
a=5
b=6
print(a  is not b)
#membership operator
#the membership operator used ensure that whether the provided substring is present not in a sequence
#Checks if a value is in a sequence like list, string, etc.
# there are two types
# in (notin)
str1="helloiamanitha"
print( "hello" in str1)
print("hello" not in str1)
#assignment operators
#the assignment operator used to assign values to the variables(+=,-=,*=,/=,//=,%=,**=)
x=10
x=x+2
print(x)
x-=2
print(x)
x*=2
print(x)
x/=2
print(x)
x=10
x//=2
print(x)
x=10
x%=2
print(x)
x=5
x**=2
print(x)
#logical operator
#the logical operator used to combine the conditions
#they are types (AND,OR,NOT)


age = 25
citizen = True

if age >= 18 and citizen == True:
    print("Eligible to vote")
else:
    print("Not eligible to vote")
    
age = 25
citizen = True

if age >= 18 or citizen == True:
    print("Eligible to vote")
else:
    print("Not eligible to vote")
age=True
if not age:
    print("this is true")
else:
    print("this is not true")
#control statements the control statements used to executes block of code based on the condition
# they are three types (if elif else)

age=18
if age>18:
    print("eligible")
elif age==18:
    print("eligible for vote")
else:
    print("not eligible")

# control statements
#for,range and while
#range loop it will extract the index of the sequence
arr="helloworld"
for i in range(len(arr)):
    print(i)
# for loop  it will extract the value from the sequence directly
for i in arr:
    print(i)
#while loop
a="hello"
i=0
while i<=len(a):
    print(a[i])
    i+=1
    




