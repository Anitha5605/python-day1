#1)list is a ordered collection of elements which stores homogenious and heterogenious data types means integer,string and it can store list as a single value
#list is mutable whcih means we can modify them by adding,removing and updating elements within list
#it is a built_in data structute
#list is defined by [] square brackets and elements stored in a index starting from 0
#on the other hand tuple is unordered collection of elements placed within a parenthesis and it is immutable which means we cont change their content once it is created
#2)How do you add multiple elements to a list at once?
# the extend() adds multiple elements in a list at once
#example:
#l1=[1,2,3,4,5]
#l1.extend([10,20])
#print(l1)
#3)What is the difference between append(), extend(), and insert() in Python lists?.
#append() adds only single value at the end of the list
#extend() adds multiple values at the end of the list
#insert() add a value at particular position  and it has two parameters index and value
#How can you remove duplicate elements from a list?
 #by converting into set the set will remove duplicats automatically

#How do list slicing and negative indexing work in Python?
#slicing extract some portion from list and return as new list without modifying the original list it has three parameters
#slice[start:stop:step]
#negitive indexing means we can access the values at end of list instead of starting  -1 index refers to the last element and -2 index 2last element and so on moving backword
# How can you iterate over a list with both index and value in Python?
#by using enumerate is a built in function it extract both value and index from the sequence like string list at once

