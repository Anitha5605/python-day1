what is set?
#set is a unordered, unindexed collection of unique elements placed in a {} curly bases
#set is mutable which means we can modify their content this is mainly used when the user wants to remove duplicates
#set has methods :
   ## 1)add ->add single element into the set
   # 2)update->add multiple element into the set
    #3)remove->it remove the first occurance element from the set if the element is not present it will throw an error
    #4)discard->it remove the first occurance element from the set it the element is not present it does nothing
#properties of set :
   # 1)unorded
   #3)unique
   # 4)not indexed
#s={1,2,3,4,5}
#s.add(10)
#print(s)
s =set([1,2,3,4,5,6])
s.update([10,20])
print(s)
s1={1,2,3,4,5,6}
s1.remove(6)
print(s1)
s3={1,2,3}
s3.discard(30)
print(s3)
What is the difference between discard() and remove() in sets?

remove(30) raises an error if element is not in the set.

discard(10) it does nothing when the element is not present
