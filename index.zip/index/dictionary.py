#dictionary is a unordered collection of elements in the form of key value pairs
#keys must be unique whereas values can be duplicates
#we can access the dictionary by using keys
# the  dictionary is mutable
#it has different methods 1)keys 2)values 3) items
#keys retrieve all keys present in the dictionary
#values retrieve all values present in the dictionary
#item() it gives both value and keys in the dictionary
#print(d["name"])
#for i,j in d.items():
   # print(i,j)
for i in d.keys():
    print(i)
for j in d.values():
    print(j)


